import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class RecipeManager {
    private List<Recipe> recipes;

    public RecipeManager() {
        recipes = new ArrayList<>();
    }

    public void addRecipe(Recipe recipe) {
        recipes.add(recipe);
    }

    public void removeRecipe(String recipeName) {
        recipes.removeIf(recipe -> recipe.getName().equalsIgnoreCase(recipeName));
    }

    public Recipe findRecipeByName(String name) {
        return recipes.stream()
                .filter(recipe -> recipe.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    public List<Recipe> findRecipesByIngredient(String ingredient) {
        return recipes.stream()
                .filter(recipe -> recipe.getIngredients().contains(ingredient))
                .collect(Collectors.toList());
    }

    public void printRecipes() {
        recipes.forEach(System.out::println);
    }
}

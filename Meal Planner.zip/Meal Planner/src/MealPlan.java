import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MealPlan {
    private Map<String, List<Recipe>> weeklyPlan;

    public MealPlan() {
        weeklyPlan = new HashMap<>();
        weeklyPlan.put("Montag", null);
        weeklyPlan.put("Dienstag", null);
        weeklyPlan.put("Mittwoch", null);
        weeklyPlan.put("Donnerstag", null);
        weeklyPlan.put("Freitag", null);
        weeklyPlan.put("Samstag", null);
        weeklyPlan.put("Sonntag", null);
    }

    public void addRecipesToDay(String day, List<Recipe> recipes) {
        weeklyPlan.put(day, recipes);
    }

    public void removeRecipesFromDay(String day) {
        weeklyPlan.put(day, null);
    }

    public void printWeeklyPlan() {
        weeklyPlan.forEach((day, recipes) -> {
            System.out.println(day + ":");
            if (recipes != null) {
                recipes.forEach(System.out::println);
            } else {
                System.out.println("Keine Rezepte geplant.");
            }
        });
    }

    public void printCaloriesForDay(String day) {
        List<Recipe> recipes = weeklyPlan.get(day);
        if (recipes != null && !recipes.isEmpty()) {
            int totalCalories = recipes.stream().mapToInt(Recipe::getCalories).sum();
            System.out.println("Gesamtkalorien für " + day + ": " + totalCalories);
        } else {
            System.out.println("Keine Rezepte geplant für " + day + ".");
        }
    }
}

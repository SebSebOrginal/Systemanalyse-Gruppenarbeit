import java.util.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RecipeManager manager = new RecipeManager();
        MealPlan mealPlan = new MealPlan();
        WeightTracker weightTracker = new WeightTracker();

        while (true) {
            System.out.println("Wähle eine Option: \n(1) Rezept hinzufügen \n(2) Rezept löschen \n(3) Rezept zum Wochentag hinzufügen \n(4) Rezepte von Wochentag entfernen \n(5) Wochentagsplan anzeigen \n(6) Kalorien für einen Tag anzeigen \n(7) Gewicht hinzufügen \n(8) Gewichtsverlauf anzeigen \n(9) Beenden");
            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    System.out.println("Rezeptname:");
                    String name = scanner.nextLine();
                    System.out.println("Zutaten (kommagetrennt):");
                    List<String> ingredients = Arrays.asList(scanner.nextLine().split(","));
                    System.out.println("Anleitung:");
                    String instructions = scanner.nextLine();
                    System.out.println("Kalorien:");
                    int calories = scanner.nextInt();
                    scanner.nextLine();
                    Recipe recipe = new Recipe(name, ingredients, instructions, calories);
                    manager.addRecipe(recipe);
                    break;
                case 2:
                    System.out.println("Rezeptname zum Löschen:");
                    String deleteName = scanner.nextLine();
                    manager.removeRecipe(deleteName);
                    break;
                case 3:
                    System.out.println("Wochentag:");
                    String dayToAdd = scanner.nextLine();
                    System.out.println("Rezeptname:");
                    String recipeNameToAdd = scanner.nextLine();
                    Recipe recipeToAdd = manager.findRecipeByName(recipeNameToAdd);
                    if (recipeToAdd != null) {
                        mealPlan.addRecipesToDay(dayToAdd, Arrays.asList(recipeToAdd));
                    } else {
                        System.out.println("Rezept nicht gefunden.");
                    }
                    break;
                case 4:
                    System.out.println("Wochentag zum Löschen:");
                    String dayToRemove = scanner.nextLine();
                    mealPlan.removeRecipesFromDay(dayToRemove);
                    break;
                case 5:
                    mealPlan.printWeeklyPlan();
                    break;
                case 6:
                    System.out.println("Wochentag für Kalorienberechnung:");
                    String dayForCalories = scanner.nextLine();
                    mealPlan.printCaloriesForDay(dayForCalories);
                    break;
                case 7:
                    System.out.println("Gib dein aktuelles Gewicht ein (kg):");
                    double weight = scanner.nextDouble();
                    scanner.nextLine();
                    weightTracker.addWeight(weight);
                    break;
                case 8:
                    weightTracker.printWeights();
                    break;
                case 9:
                    System.out.println("Programm beendet.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Ungültig.");
                    break;
            }
        }
    }
}

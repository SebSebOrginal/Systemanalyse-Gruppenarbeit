import java.util.ArrayList;
import java.util.List;

public class Recipe {
    private String name;
    private List<String> ingredients;
    private String instructions;
    private int calories;

    public Recipe(String name, List<String> ingredients, String instructions, int calories) {
        this.name = name;
        this.ingredients = new ArrayList<>(ingredients);
        this.instructions = instructions;
        this.calories = calories;
    }

    public String getName() {
        return name;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public String getInstructions() {
        return instructions;
    }

    public int getCalories() {
        return calories;
    }

    @Override
    public String toString() {
        return "Rezept: " + name + "\nZutaten: " + ingredients + "\nAnleitung: " + instructions + "\nKalorien: " + calories;
    }
}

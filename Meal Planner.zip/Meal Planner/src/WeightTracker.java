import java.util.ArrayList;
import java.util.List;

public class WeightTracker {
    private List<Double> weights;

    public WeightTracker() {
        this.weights = new ArrayList<>();
    }

    public void addWeight(double weight) {
        weights.add(weight);
    }

    public void printWeights() {
        System.out.println("Gewichtsverlauf:");
        for (double weight : weights) {
            System.out.println(weight + " kg");
        }
    }
}

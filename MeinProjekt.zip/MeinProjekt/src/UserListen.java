import java.util.ArrayList;
import java.util.Scanner;

public class UserListen {
    //Verwaltung der Verschiedenen Listen

        Scanner sc = new Scanner(System.in);
        String a;
        public ArrayList<String> username = new ArrayList<>();
        public ArrayList <String> passwort = new ArrayList<>();
        public ArrayList <String> test = new ArrayList<>();
        public void test (){

            test.add(sc.next());
            System.out.println(test.toString());

        }


    }
